﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EviTest
{
    public partial class FoodInfo : Form
    {
        SqlConnection sqlcon = new SqlConnection(@"Data Source=DESKTOP-NCEEQO4;Initial Catalog=FoodDB;Integrated Security=True");
        SqlTransaction tran;
        public FoodInfo()
        {
            InitializeComponent();
        }

        
        public void loadGridData(int id)
        {
            sqlcon.Open();
            SqlDataAdapter sda = new SqlDataAdapter(@"select FoodId ,FoodeName,companyId ,FoodImage ,Price from Food where FoodId =" + id + "", sqlcon);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                txtId.Text = dt.Rows[0][0].ToString();
                txtFoodName.Text = dt.Rows[0][1].ToString();
                cmbCoompanyName.SelectedValue = dt.Rows[0][2].ToString();

                MemoryStream ms = new MemoryStream((byte[])dt.Rows[0][3]);
                Image img = Image.FromStream(ms);
                pictureBox1.Image = img;
                txtPrice.Text = dt.Rows[0][4].ToString();
            }
            sqlcon.Close();

            sqlcon.Open();
            SqlDataAdapter sda1 = new SqlDataAdapter(@"select id,supplierName,locationId from FoodSupplier where FoodId =" + id + "", sqlcon);
            DataTable dt1 = new DataTable();
            sda1.Fill(dt1);
            dataGridView1.DataSource = dt1;

            sqlcon.Close();
        }


        //private void btnClear_Click(object sender, EventArgs e)
        //{
        //    clearData();
        //}
        //private void clearData()
        //{
        //    txtId.Clear();
        //    txtFoodName.Clear();
        //    cmbCoompanyName.SelectedIndex = 0;

        //    txtPicture.Clear();
        //    pictureBox1.Image = null;
        //    txtPrice.Clear();
        //    if (dataGridView1.DataSource == null)
        //    {
        //        dataGridView1.Rows.Clear();

        //    }
        //    else
        //    {
        //        dataGridView1.DataSource = (dataGridView1.DataSource as DataTable).Clone();

        //    }
        //}


        private void LoadGrid()
        {
            sqlcon.Open();
            SqlDataAdapter sqlda = new SqlDataAdapter(@"select FoodId ,FoodeName,companyName,FoodImage,Price  from Food f join companyInfo c on f.companyId=c.companyId", sqlcon);
            DataTable dt = new DataTable();
            sqlda.Fill(dt);
            dataGridView2.DataSource = dt;
            sqlcon.Close();
        }
        private void CompanyComboBox()
        {
            sqlcon.Open();
            SqlDataAdapter sqlda = new SqlDataAdapter("select * from companyInfo", sqlcon);
            DataSet ds = new DataSet();
            sqlda.Fill(ds);
            DataRow newRow = ds.Tables[0].NewRow();
            newRow[0] = "-1";
            newRow[1] = "---Select Company---";
            ds.Tables[0].Rows.InsertAt(newRow, 0);
            cmbCoompanyName.DataSource = ds.Tables[0];
            cmbCoompanyName.DisplayMember = "companyName";
            cmbCoompanyName.ValueMember = "companyId";
            sqlcon.Close();

        }

       
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int id = Convert.ToInt32(dataGridView2.Rows[e.RowIndex].Cells[0].Value);
            sqlcon.Open();
            SqlDataAdapter sda = new SqlDataAdapter(@"select FoodId ,FoodeName,companyId ,FoodImage ,Price from Food where FoodId=" + id + "", sqlcon);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                txtId.Text = dt.Rows[0][0].ToString();
                txtFoodName.Text = dt.Rows[0][1].ToString();
                cmbCoompanyName.SelectedValue = dt.Rows[0][2].ToString();

                MemoryStream ms = new MemoryStream((byte[])dt.Rows[0][3]);
                Image img = Image.FromStream(ms);
                pictureBox1.Image = img;
                txtPrice.Text = dt.Rows[0][4].ToString();
            }

            SqlDataAdapter sda1 = new SqlDataAdapter(@"select id,supplierName, locationId from FoodSupplier where FoodId =" + id + "", sqlcon);
            DataTable dt1 = new DataTable();
            sda1.Fill(dt1);
            dataGridView1.DataSource = dt1;

            sqlcon.Close();
        }

        private void btnInsert_Click_1(object sender, EventArgs e)
        {
            try
            {
                Image img = Image.FromFile(txtPicture.Text);
                MemoryStream ms = new MemoryStream();
                img.Save(ms, ImageFormat.Bmp);
                sqlcon.Open();

                tran = sqlcon.BeginTransaction();

                SqlCommand sqlcmd = new SqlCommand("insert into Food(FoodId ,FoodeName ,companyId ,FoodImage ,Price ) values (@i,@n,@ci,@fi,@p)", sqlcon, tran);
                sqlcmd.Parameters.AddWithValue("@i", txtId.Text);
                sqlcmd.Parameters.AddWithValue("@n", txtFoodName.Text);
                sqlcmd.Parameters.AddWithValue("@ci", cmbCoompanyName.SelectedValue);

                sqlcmd.Parameters.Add(new SqlParameter("@fi", SqlDbType.VarBinary) { Value = ms.ToArray() });
                sqlcmd.Parameters.AddWithValue("@p", txtPrice.Text);
                sqlcmd.ExecuteNonQuery();
                foreach (DataGridViewRow dgvRow in dataGridView1.Rows)
                {
                    if (dgvRow.IsNewRow) break;
                    else
                    {
                        SqlCommand sqlcmd1 = new SqlCommand(@"insert into FoodSupplier(FoodId,supplierName ,cityId ) values(@fi,@sn,@l)", sqlcon, tran);
                        sqlcmd1.Parameters.AddWithValue("@fi", Convert.ToInt32(txtId.Text));
                        sqlcmd1.Parameters.AddWithValue("@sn", dgvRow.Cells["dgvtxtSuplier"].Value);
                        sqlcmd1.Parameters.AddWithValue("@l", dgvRow.Cells["cmdcity"].Value);

                        sqlcmd1.ExecuteNonQuery();
                    }
                }

                tran.Commit();

                MessageBox.Show("Insert Successfull", "Insert Alert");
                // clearData();
                sqlcon.Close();
            }
            catch (Exception ex)
            {
                tran.Rollback();

                MessageBox.Show("Invalid Input\n" + ex.Message);
                sqlcon.Close();
            }
            LoadGrid();

        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Image img = Image.FromFile(openFileDialog1.FileName);
                this.pictureBox1.Image = img;
                txtPicture.Text = openFileDialog1.FileName;
            }
        }



        private void FoodInfo_Load_1(object sender, EventArgs e)
        {
            LoadPosition();
            LoadGrid();
            CompanyComboBox();
            
        }

        void LoadPosition()
        {
            sqlcon.Open();
            SqlDataAdapter sqlda = new SqlDataAdapter("select * from city", sqlcon);
            DataTable dt = new DataTable();
            sqlda.Fill(dt);
            DataRow TopItem = dt.NewRow();
            TopItem[0] = "-1";
            TopItem[1] = "--select--";
            dt.Rows.InsertAt(TopItem, 0);
            cmdcity.ValueMember = "cityId";
            cmdcity.DisplayMember = "cityName";
            cmdcity.DataSource = dt;

            sqlcon.Close();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                sqlcon.Open();

                tran = sqlcon.BeginTransaction();

                SqlCommand sqlcmd1 = new SqlCommand(@"delete from FoodSupplier where FoodId =" + Convert.ToInt32(txtId.Text) + " ", sqlcon, tran);
                sqlcmd1.ExecuteNonQuery();

                SqlCommand sqlcmd = new SqlCommand(@"delete from Food where FoodId =" + txtId.Text + " ", sqlcon, tran);
                sqlcmd.ExecuteNonQuery();

                tran.Commit();

                MessageBox.Show("Delete Successfully !!", "Delete Message");
                clearData();
                sqlcon.Close();
            }
            catch (Exception ex)
            {
                tran.Rollback();
                MessageBox.Show("Data Not Valid !!" + ex.Message);
                sqlcon.Close();
            }
            LoadGrid();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                sqlcon.Open();
                tran = sqlcon.BeginTransaction();
                if (txtPicture.Text != "")
                {
                    Image img = Image.FromFile(txtPicture.Text);
                    MemoryStream ms = new MemoryStream();
                    img.Save(ms, ImageFormat.Bmp);
                    SqlCommand sqlcmd = new SqlCommand(@"update Food set FoodeName =@n,companyId =@ci ,
             FoodImage =@fi,price=@p where FoodId=@i", sqlcon, tran);
                    sqlcmd.Parameters.AddWithValue("@i", txtId.Text);
                    sqlcmd.Parameters.AddWithValue("@n", txtFoodName.Text);
                    sqlcmd.Parameters.AddWithValue("@ci", cmbCoompanyName.SelectedValue);

                    sqlcmd.Parameters.Add(new SqlParameter("@fi", SqlDbType.VarBinary) { Value = ms.ToArray() });
                    sqlcmd.Parameters.AddWithValue("@p", txtPrice.Text);
                    sqlcmd.ExecuteNonQuery();
                }
                else
                {
                    SqlCommand sqlcmd = new SqlCommand(@"update Food set FoodeName=@n,companyId=@ci ,
             Price =@p where FoodId=@i", sqlcon, tran);
                    sqlcmd.Parameters.AddWithValue("@i", txtId.Text);
                    sqlcmd.Parameters.AddWithValue("@n", txtFoodName.Text);
                    sqlcmd.Parameters.AddWithValue("@ci", cmbCoompanyName.SelectedValue);

                    sqlcmd.Parameters.AddWithValue("@p", txtPrice.Text);
                    sqlcmd.ExecuteNonQuery();
                }
                foreach (DataGridViewRow dgvRow in dataGridView1.Rows)
                {
                    if (dgvRow.IsNewRow) break;
                    else
                    {
                        if (dgvRow.Cells["dgvtxtid"].Value.ToString() != "")
                        {
                            SqlCommand sqlcmd1 = new SqlCommand(@"update FoodSupplier set supplierName =@sn, cityId=@c where id=@id", sqlcon, tran);
                            sqlcmd1.Parameters.AddWithValue("@id", Convert.ToInt32(dgvRow.Cells["dgvtxtId"].Value));
                            sqlcmd1.Parameters.AddWithValue("@sn", dgvRow.Cells["dgvtxtSuplier"].Value);
                            sqlcmd1.Parameters.AddWithValue("@c", dgvRow.Cells["cmdcity"].Value);
                            sqlcmd1.ExecuteNonQuery();
                        }
                        else
                        {
                            SqlCommand sqlcmd1 = new SqlCommand(@"insert into FoodSupplier(FoodId ,FoodeName ,cityId) values(@fi,@fn,@c)", sqlcon, tran);
                            sqlcmd1.Parameters.AddWithValue("@ti", Convert.ToInt32(txtId.Text));
                            sqlcmd1.Parameters.AddWithValue("@fn", dgvRow.Cells["dgvtxtSuplier"].Value);
                            sqlcmd1.Parameters.AddWithValue("@c", dgvRow.Cells["cmdcity"].Value);

                            sqlcmd1.ExecuteNonQuery();
                        }
                    }
                }
                tran.Commit();
                MessageBox.Show("Update SuccessFully!!", "Update Message");
                sqlcon.Close();
            }
            catch (Exception ex)
            {
                tran.Rollback();
                MessageBox.Show("Invalid Input!!\n" + ex.Message);
                sqlcon.Close();
            }
            LoadGrid();
            loadGridData(Convert.ToInt32(txtId.Text));
            dataGridView2.CurrentCell = dataGridView2.Rows[Convert.ToInt32(txtId.Text) - 1].Cells[0];
        }

        private void btnClear_Click_1(object sender, EventArgs e)
        {
            clearData();
        }
        private void clearData()
        {
            txtId.Clear();
            txtFoodName.Clear();
            cmbCoompanyName.SelectedIndex = 0;

            txtPicture.Clear();
            pictureBox1.Image = null;
            txtPrice.Clear();
            if (dataGridView1.DataSource == null)
            {
                dataGridView1.Rows.Clear();

            }
            else
            {
                dataGridView1.DataSource = (dataGridView1.DataSource as DataTable).Clone();

            }
        }
    }
  }

