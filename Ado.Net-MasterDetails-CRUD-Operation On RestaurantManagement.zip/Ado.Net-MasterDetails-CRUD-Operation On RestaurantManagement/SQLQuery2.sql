
CREATE DATABASE FoodDB
GO
USE FoodDB
GO

CREATE TABLE companyInfo
(
	companyId int NOT NULL PRIMARY KEY,
	companyName varchar (50) NOT NULL
)
GO

CREATE TABLE location
(
	locationId int PRIMARY KEY NOT NULL,
	locationName nvarchar(50) not null
)
GO
Insert into location Values (1,'Dhaka')
Insert into location Values (2,'Chandpur')


CREATE TABLE Food
(
	FoodId int PRIMARY KEY NOT NULL,
	FoodeName varchar(50) NOT NULL,
	companyId int REFERENCES companyInfo(companyId),
	FoodImage varbinary (max) ,
	Price money NOT NULL
)
GO

CREATE TABLE FoodSupplier
(
	id int PRIMARY KEY IDENTITY(1,1) NOT NULL,
	FoodId int references Food(FoodId),
	supplierName varchar(50) NOT NULL,
	locationId int references location(locationId)	
)
GO
