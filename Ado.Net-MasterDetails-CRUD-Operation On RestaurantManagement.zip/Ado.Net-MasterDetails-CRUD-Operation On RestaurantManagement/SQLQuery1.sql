use FoodDB
go
CREATE TABLE city
(
	cityId int PRIMARY KEY NOT NULL,
	cityName nvarchar(50) not null
)
GO
Insert into city Values (1,'Dhaka')
Insert into city Values (2,'Rajshahi')
Insert into city Values (3,'Pabna')
Insert into city Values (4,'Shylet')
Insert into city Values (5,'Bogura')
GO
CREATE TABLE FoodSupplier
(
	id int PRIMARY KEY IDENTITY(1,1) NOT NULL,
	FoodId int references Food(FoodId),
	supplierName varchar(50) NOT NULL,
	cityId int references city(cityId)	
)
GO
